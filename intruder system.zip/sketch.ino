/*
  ESP32 intruder alarm: PIR motion sensor + GSM SMS alert
  Works in a simulator (Wokwi) with SIMULATE_GSM = true,
  then on real hardware (ESP32-C6 + SIM800L/SIM900) with SIMULATE_GSM = false.

  Pins (change to match your board):
    PIR output  -> GPIO 4
    Arm button  -> GPIO 7 (to GND, uses internal pull-up)
    Buzzer      -> GPIO 8
    Status LED  -> GPIO 9
    GSM TX      -> GPIO 5 (ESP32 RX)
    GSM RX      -> GPIO 6 (ESP32 TX)
*/

#define SIMULATE_GSM true          // true = print AT commands instead of using a modem

const int PIR_PIN    = 4;
const int BUTTON_PIN = 7;
const int BUZZER_PIN = 8;
const int LED_PIN    = 9;
const int GSM_RX     = 5;
const int GSM_TX     = 6;

const char* PHONE_NUMBER = "+254113343194";   // put your number here

const unsigned long EXIT_DELAY_MS = 10000;    // time to leave after arming
const unsigned long SMS_COOLDOWN_MS = 60000;  // minimum gap between SMS alerts
const unsigned long ALARM_MS = 5000;          // buzzer duration

enum State { DISARMED, ARMING, ARMED, ALARM };
State state = DISARMED;

unsigned long stateStart = 0;
unsigned long lastSms = 0;
bool smsEverSent = false;
bool lastButton = HIGH;

// ---------- GSM ----------
String readGsm(unsigned long timeoutMs) {
  String out;
  unsigned long t = millis();
  while (millis() - t < timeoutMs) {
    while (Serial1.available()) out += (char)Serial1.read();
  }
  return out;
}

bool sendAT(const String& cmd, const String& expect, unsigned long timeoutMs = 2000) {
  if (SIMULATE_GSM) {
    Serial.println("[SIM GSM] > " + cmd);
    return true;
  }
  Serial1.println(cmd);
  String resp = readGsm(timeoutMs);
  return resp.indexOf(expect) >= 0;
}

bool sendSMS(const String& text) {
  Serial.println("Sending SMS: " + text);
  if (!sendAT("AT", "OK")) return false;
  if (!sendAT("AT+CMGF=1", "OK")) return false;          // text mode
  if (!sendAT("AT+CMGS=\"" + String(PHONE_NUMBER) + "\"", ">", 5000)) return false;

  if (SIMULATE_GSM) {
    Serial.println("[SIM GSM] > " + text + " <Ctrl+Z>");
    Serial.println("[SIM GSM] +CMGS: 1  OK  (message 'sent')");
    return true;
  }
  Serial1.print(text);
  Serial1.write(26);                                      // Ctrl+Z ends the message
  String resp = readGsm(15000);
  return resp.indexOf("OK") >= 0;
}

// ---------- state handling ----------
void setState(State s) {
  state = s;
  stateStart = millis();
  const char* names[] = {"DISARMED", "ARMING", "ARMED", "ALARM"};
  Serial.printf("State -> %s\n", names[s]);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  if (!SIMULATE_GSM) {
    Serial1.begin(9600, SERIAL_8N1, GSM_RX, GSM_TX);
    delay(3000);   // let the modem register on the network
  }
  Serial.println("Intruder alarm ready. Press the button to arm/disarm.");
}

void loop() {
  // Button toggles arm/disarm (simple debounce)
  bool b = digitalRead(BUTTON_PIN);
  if (lastButton == HIGH && b == LOW) {
    if (state == DISARMED) setState(ARMING);
    else setState(DISARMED);
    delay(200);
  }
  lastButton = b;

  switch (state) {
    case DISARMED:
      digitalWrite(LED_PIN, LOW);
      digitalWrite(BUZZER_PIN, LOW);
      break;

    case ARMING:
      digitalWrite(LED_PIN, (millis() / 250) % 2);        // blink during exit delay
      if (millis() - stateStart > EXIT_DELAY_MS) setState(ARMED);
      break;

    case ARMED:
      digitalWrite(LED_PIN, HIGH);
      if (digitalRead(PIR_PIN) == HIGH) {
        Serial.println("Motion detected!");
        setState(ALARM);
        digitalWrite(BUZZER_PIN, HIGH);
        bool allowed = !smsEverSent || (millis() - lastSms > SMS_COOLDOWN_MS);
        if (allowed) {
          if (sendSMS("ALERT: Motion detected by intruder alarm")) {
            lastSms = millis();
            smsEverSent = true;
          } else {
            Serial.println("SMS failed");
          }
        } else {
          Serial.println("SMS skipped (cooldown)");
        }
      }
      break;

    case ALARM:
      digitalWrite(LED_PIN, (millis() / 100) % 2);        // fast blink
      if (millis() - stateStart > ALARM_MS) {
        digitalWrite(BUZZER_PIN, LOW);
        setState(ARMED);                                  // re-arm after the alarm
      }
      break;
  }
}